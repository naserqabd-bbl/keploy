const assert = require('node:assert/strict');

async function run() {
  const productsRes = await fetch('http://localhost:8080/api/products');
  assert.equal(productsRes.status, 200, 'BFF /api/products should return 200');
  const products = await productsRes.json();
  assert.ok(Array.isArray(products), 'products should be an array');
  assert.ok(products.length > 0, 'products should not be empty');
  assert.equal(typeof products[0].id, 'string');
  assert.equal(typeof products[0].name, 'string');
  assert.equal(typeof products[0].price, 'number');
  console.log('Smoke test passed.');
}

run().catch((error) => {
  console.error('Smoke test failed:', error.message);
  process.exit(1);
});
