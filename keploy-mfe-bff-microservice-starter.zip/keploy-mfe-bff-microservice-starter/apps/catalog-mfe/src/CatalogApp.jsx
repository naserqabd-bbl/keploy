import React from 'react';

export default function CatalogApp({ products = [], loading = false, error = '' }) {
  return (
    <section style={{ fontFamily: 'Arial, sans-serif', padding: 24, border: '1px solid #ddd', borderRadius: 12 }}>
      <h2 style={{ marginTop: 0 }}>Catalog Micro Frontend</h2>
      <p style={{ color: '#555' }}>This remote MFE renders catalog data received via the shell app.</p>
      {loading && <p>Loading products...</p>}
      {error && <p style={{ color: 'crimson' }}>{error}</p>}
      {!loading && !error && (
        <div style={{ display: 'grid', gap: 12 }}>
          {products.map((product) => (
            <article key={product.id} style={{ padding: 16, border: '1px solid #eee', borderRadius: 10 }}>
              <strong>{product.name}</strong>
              <div>Category: {product.category}</div>
              <div>Price: ${product.price.toFixed(2)}</div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
