import React from 'react';
import ReactDOM from 'react-dom/client';
import CatalogApp from './CatalogApp';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CatalogApp products={[]} loading={false} error="This MFE is meant to be consumed by the shell app." />
  </React.StrictMode>
);
