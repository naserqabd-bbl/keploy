import React, { Suspense, useEffect, useState } from 'react';

const RemoteCatalogApp = React.lazy(() => import('catalog_mfe/CatalogApp'));
const apiBaseUrl = import.meta.env.VITE_BFF_BASE_URL || 'http://localhost:8080';

export default function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadProducts = async () => {
      try {
        const response = await fetch(`${apiBaseUrl}/api/products`);
        if (!response.ok) {
          throw new Error(`Unexpected status ${response.status}`);
        }
        const data = await response.json();
        setProducts(data);
      } catch (err) {
        setError(err.message || 'Could not load products');
      } finally {
        setLoading(false);
      }
    };

    loadProducts();
  }, []);

  return (
    <main style={{ maxWidth: 900, margin: '0 auto', padding: 24, fontFamily: 'Arial, sans-serif' }}>
      <h1>MFE + BFF + Microservice Demo</h1>
      <p>
        The shell app loads a remote micro frontend and fetches data through the BFF. The BFF then calls the
        downstream microservice.
      </p>
      <Suspense fallback={<p>Loading remote micro frontend...</p>}>
        <RemoteCatalogApp products={products} loading={loading} error={error} />
      </Suspense>
    </main>
  );
}
