import cors from 'cors';
import express from 'express';

const app = express();
const port = process.env.PORT || 8081;

app.use(cors());
app.use(express.json());

const products = [
  { id: 'p-100', name: 'Mechanical Keyboard', category: 'Accessories', price: 89.99 },
  { id: 'p-200', name: '27-inch Monitor', category: 'Displays', price: 249.99 },
  { id: 'p-300', name: 'USB-C Dock', category: 'Accessories', price: 129.5 }
];

app.get('/health', (_req, res) => {
  res.json({ service: 'product-service', status: 'ok' });
});

app.get('/products', (_req, res) => {
  res.json(products);
});

app.listen(port, () => {
  console.log(`product-service listening on http://localhost:${port}`);
});
