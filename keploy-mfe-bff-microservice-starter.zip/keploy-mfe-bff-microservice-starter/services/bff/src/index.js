import cors from 'cors';
import express from 'express';

const app = express();
const port = process.env.PORT || 8080;
const productServiceUrl = process.env.PRODUCT_SERVICE_URL || 'http://localhost:8081';

app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => {
  res.json({ service: 'bff', status: 'ok', downstream: productServiceUrl });
});

app.get('/api/products', async (_req, res) => {
  try {
    const response = await fetch(`${productServiceUrl}/products`);
    if (!response.ok) {
      return res.status(502).json({ message: 'Downstream service returned an error' });
    }

    const products = await response.json();
    const transformed = products.map((product) => ({
      ...product,
      price: Number(product.price)
    }));

    res.json(transformed);
  } catch (error) {
    res.status(500).json({ message: 'Could not reach product service', details: error.message });
  }
});

app.listen(port, () => {
  console.log(`bff listening on http://localhost:${port}`);
  console.log(`proxying product requests to ${productServiceUrl}`);
});
