#!/usr/bin/env bash
set -euo pipefail

# Ensure perf stack is up (InfluxDB + Grafana)
docker compose -f docker-compose.perf.yml up -d

# Run k6 (official image) and send metrics to InfluxDB
docker run --rm \
  --network host \
  -e K6_OUT=influxdb=http://localhost:8086/k6 \
  -e BASE_URL=http://localhost:3000 \
  -v "$(pwd)/perf/k6:/scripts" \
  grafana/k6:0.54.0 run /scripts/profile.js
