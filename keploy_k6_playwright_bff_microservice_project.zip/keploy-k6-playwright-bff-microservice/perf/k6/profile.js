import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  scenarios: {
    steady: {
      executor: 'constant-arrival-rate',
      rate: 20, // req/s
      timeUnit: '1s',
      duration: '30s',
      preAllocatedVUs: 20,
      maxVUs: 200,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<500'],
  },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:3000';

export default function () {
  const id = Math.floor(Math.random() * 3) + 1;
  const res = http.get(`${BASE_URL}/api/v1/profile/${id}`);
  check(res, {
    'status is 200': (r) => r.status === 200,
    'has fullName': (r) => !!r.json('fullName'),
  });
  sleep(0.2);
}
