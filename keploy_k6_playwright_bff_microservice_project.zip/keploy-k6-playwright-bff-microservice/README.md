# BFF + Microservice demo: Keploy contract tests + Grafana/k6 perf + Playwright API automation (Python)

This repo is a **ready-to-run starter project** that demonstrates:
- **BFF layer** calling a downstream **microservice**
- **API contract-style regression testing** via **Keploy record/replay**
- **Performance testing** with **Grafana k6**
- **API automation** with **Python Playwright**

> Designed to run locally with Docker/Compose.

---

## 1) Architecture

- `services/user-service` (Python/FastAPI): provides `/api/v1/users/:id`
- `services/bff` (Node/Express): provides `/api/v1/profile/:id` and calls `user-service`
- `tests/playwright_api` (Python): API tests using Playwright `APIRequestContext`
- `perf/k6` (k6): load test scripts against BFF
- `observability` (Grafana + InfluxDB): dashboards for k6 output
- `keploy` (Keploy): record/replay tests for API regression/contract checks

---

## 2) Prerequisites

- Docker + Docker Compose
- (Optional) Node 18+ and Python 3.10+ if you want to run services outside Docker

---

## 3) Run services

```bash
docker compose up --build
```

Endpoints:
- BFF: http://localhost:3000/api/v1/profile/1
- User Service: http://localhost:8000/api/v1/users/1
- Swagger (User Service): http://localhost:8000/docs

---

## 4) Playwright API automation (Python)

Run from your host (recommended):

```bash
cd tests/playwright_api
python -m venv .venv
# Linux/Mac:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate

pip install -r requirements.txt
python -m playwright install
pytest -q
```

---

## 5) Keploy record/replay (API regression / "contract-style" checks)

Keploy can record the HTTP interactions and replay them later as tests.
This starter uses Keploy **docker** to keep setup simple.

### Record
1. Start the stack:
```bash
docker compose up --build -d
```

2. Record tests by running Keploy in record mode and then calling the BFF endpoint:
```bash
make keploy-record
```

This will:
- run Keploy in record mode
- trigger sample traffic to `GET /api/v1/profile/1`
- save recordings under `keploy/tests/`

### Replay (test)
```bash
make keploy-test
```

Notes:
- Keploy works best on Linux with `--network host`. This project uses a docker network + explicit hostnames to work cross-platform.
- You can add more traffic by curling other endpoints while recording.

---

## 6) k6 performance testing + Grafana

Bring up the observability stack:

```bash
docker compose -f docker-compose.perf.yml up -d
```

Run k6 and send metrics to InfluxDB:

```bash
make k6-run
```

Open Grafana:
- http://localhost:3001
- user/pass: `admin` / `admin` (you will be prompted to change)

A pre-provisioned dashboard is included under `observability/grafana/dashboards/`.

---

## 7) Useful commands

```bash
make up         # start app stack
make down       # stop app stack
make logs       # follow logs
make smoke      # quick curl check
make keploy-record
make keploy-test
make k6-run
```

---

## 8) Customize

- Add more BFF endpoints in `services/bff/src/index.js`
- Add more microservice endpoints in `services/user-service/app/main.py`
- Add more Playwright API tests under `tests/playwright_api/tests`
- Tune k6 scenarios in `perf/k6/profile.js`

---

## Troubleshooting

- If ports are in use, edit `docker-compose.yml` / `docker-compose.perf.yml`
- If Keploy tests are empty, ensure `make keploy-record` completed and `keploy/tests/` has yaml files.

---

## License
MIT
