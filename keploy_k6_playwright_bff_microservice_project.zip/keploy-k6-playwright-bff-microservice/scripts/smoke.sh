#!/usr/bin/env bash
set -euo pipefail
echo "BFF health:"
curl -sS http://localhost:3000/health && echo
echo "Profile 1:"
curl -sS http://localhost:3000/api/v1/profile/1 && echo
