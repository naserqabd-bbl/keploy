import os
import pytest
from playwright.sync_api import sync_playwright

BFF_BASE_URL = os.getenv("BFF_BASE_URL", "http://localhost:3000")

@pytest.mark.parametrize("user_id, expected_plan", [
    (1, "pro"),
    (2, "free"),
    (3, "team"),
])
def test_profile_endpoint(user_id: int, expected_plan: str):
    with sync_playwright() as p:
        req = p.request.new_context(base_url=BFF_BASE_URL)
        resp = req.get(f"/api/v1/profile/{user_id}")
        assert resp.status == 200
        data = resp.json()
        assert data["id"] == user_id
        assert "fullName" in data and len(data["fullName"]) > 2
        assert data["plan"] == expected_plan
        assert data["meta"]["source"] == "user-service"
        req.dispose()

def test_health():
    with sync_playwright() as p:
        req = p.request.new_context(base_url=BFF_BASE_URL)
        resp = req.get("/health")
        assert resp.status == 200
        assert resp.json()["status"] == "ok"
        req.dispose()
