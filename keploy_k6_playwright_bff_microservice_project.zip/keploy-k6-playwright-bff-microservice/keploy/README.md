# Keploy

This folder contains helper scripts and the place where Keploy stores recorded tests.

- `keploy/tests/` will be created/filled after recording.
- `keploy/scripts/record.sh` runs record mode and generates sample traffic.
- `keploy/scripts/test.sh` runs replay mode.

If you want to record additional flows, run `record.sh` and hit more endpoints while recording.
