#!/usr/bin/env bash
set -euo pipefail

docker compose up --build -d

echo "Running Keploy tests (replay)..."
docker run --rm \
  -v "$(pwd)/keploy:/keploy-data" \
  --network host \
  keploy/keploy:latest test --path /keploy-data

echo "Done."
