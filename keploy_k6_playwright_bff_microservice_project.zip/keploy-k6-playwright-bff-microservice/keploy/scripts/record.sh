#!/usr/bin/env bash
set -euo pipefail

# Start app stack
docker compose up --build -d

# Wait for services
echo "Waiting for services..."
for i in {1..30}; do
  if curl -sf http://localhost:3000/health >/dev/null; then
    break
  fi
  sleep 1
done

mkdir -p keploy/tests

# Run Keploy in record mode using official image.
# This uses a docker network and targets BFF by host port.
# Keploy will capture the traffic and store tests under /keploy-data (mounted).
echo "Starting Keploy (record)..."
docker run --rm \
  -v "$(pwd)/keploy:/keploy-data" \
  --network host \
  keploy/keploy:latest record -c "sh -c 'echo Recording...; sleep 2'" --path /keploy-data

# Generate sample traffic (recordings happen at kernel/network layer in many setups)
# If your OS requires, run Keploy on Linux for best results.
echo "Generating sample traffic..."
curl -sS http://localhost:3000/api/v1/profile/1 >/dev/null
curl -sS http://localhost:3000/api/v1/profile/2 >/dev/null
curl -sS http://localhost:3000/api/v1/profile/3 >/dev/null

echo "Done. If keploy/tests is empty, run on Linux or adjust Keploy integration for your environment."
