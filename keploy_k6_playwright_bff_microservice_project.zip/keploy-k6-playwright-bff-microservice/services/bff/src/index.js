import express from "express";
import fetch from "node-fetch";

const app = express();

const PORT = process.env.PORT || 3000;
const USER_SERVICE_URL = process.env.USER_SERVICE_URL || "http://localhost:8000";

app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "bff" });
});

/**
 * BFF endpoint: combines downstream user-service data into a "profile"
 * Example: GET /api/v1/profile/1
 */
app.get("/api/v1/profile/:id", async (req, res) => {
  const id = req.params.id;
  const userUrl = `${USER_SERVICE_URL}/api/v1/users/${id}`;

  try {
    const r = await fetch(userUrl, { headers: { "x-bff-trace": "demo" } });
    if (!r.ok) {
      return res.status(r.status).json({ error: "downstream_error", status: r.status });
    }

    const user = await r.json();

    // "BFF transform" example
    const profile = {
      id: user.id,
      fullName: `${user.first_name} ${user.last_name}`,
      email: user.email,
      plan: user.plan,
      meta: {
        source: "user-service",
        fetched_at: new Date().toISOString()
      }
    };

    res.json(profile);
  } catch (e) {
    res.status(500).json({ error: "bff_exception", message: String(e) });
  }
});

app.listen(PORT, () => {
  console.log(`BFF listening on :${PORT} (USER_SERVICE_URL=${USER_SERVICE_URL})`);
});
