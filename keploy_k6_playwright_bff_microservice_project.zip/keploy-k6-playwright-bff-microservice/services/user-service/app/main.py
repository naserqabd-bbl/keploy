from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict

app = FastAPI(title="user-service", version="1.0.0")

class User(BaseModel):
    id: int
    first_name: str
    last_name: str
    email: str
    plan: str

# Fake in-memory store for demo purposes
USERS: Dict[int, User] = {
    1: User(id=1, first_name="Abdullah", last_name="Naser", email="abdullah@example.com", plan="pro"),
    2: User(id=2, first_name="Ayesha", last_name="Rahman", email="ayesha@example.com", plan="free"),
    3: User(id=3, first_name="Hasan", last_name="Khan", email="hasan@example.com", plan="team"),
}

@app.get("/health")
def health():
    return {"status": "ok", "service": "user-service"}

@app.get("/api/v1/users/{user_id}", response_model=User)
def get_user(user_id: int):
    user = USERS.get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="user_not_found")
    return user
