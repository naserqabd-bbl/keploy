# Services

- `bff` (Node/Express) on :3000
- `user-service` (FastAPI) on :8000

Both are wired together in `docker-compose.yml`.
